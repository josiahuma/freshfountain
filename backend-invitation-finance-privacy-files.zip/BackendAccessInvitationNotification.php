<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class BackendAccessInvitationNotification extends Notification
{
    use Queueable;

    public function __construct(
        private readonly string $plainToken,
        private readonly bool $isResend = false,
    ) {
    }

    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $url = route('backend-invitation.show', [
            'token' => $this->plainToken,
        ]);

        return (new MailMessage)
            ->subject(
                $this->isResend
                    ? 'Your Fresh Fountain backend access link'
                    : 'You have been invited to Fresh Fountain Hub'
            )
            ->greeting('Hello '.$notifiable->name.',')
            ->line(
                $this->isResend
                    ? 'A new secure account setup link has been created for you.'
                    : 'You have been granted access to the Fresh Fountain Church administration hub.'
            )
            ->line('Use the button below to choose your password and activate your backend account.')
            ->action('Set up my account', $url)
            ->line('This secure link expires in 24 hours.')
            ->line('If you were not expecting this invitation, you can safely ignore this email.');
    }
}
